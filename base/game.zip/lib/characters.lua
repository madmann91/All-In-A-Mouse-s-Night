g_print("Registering characters...\n")

g_registercharacter("peanut",0.1,1.0,0,"characters\\peanut\\peanut.mdl","characters\\peanut\\peanut.skt","characters\\peanut\\peanut.png")
g_registercharacter("rat",0.5,2.0,1,"characters\\rat\\rat.mdl","characters\\rat\\rat.skt","characters\\rat\\rat.png")