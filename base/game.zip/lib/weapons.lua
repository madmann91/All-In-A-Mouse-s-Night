g_print("Registering weapons...\n")

g_registerweapon("m5","ray","weapons\\m5\\m5.mdl","weapons\\m5\\m5.png")
g_registerweapon("ka11","ray","weapons\\ka11\\ka11.mdl","weapons\\ka11\\ka11.png")
g_registerweapon("thompdad","ray","weapons\\thompdad\\thompdad.mdl","weapons\\thompdad\\thompdad.png")
g_registerweapon("longneck","ray","weapons\\longneck\\longneck.mdl","weapons\\longneck\\longneck.png")
g_registerweapon("magum","ray","weapons\\magum\\magum.mdl","weapons\\magum\\magum.png")
